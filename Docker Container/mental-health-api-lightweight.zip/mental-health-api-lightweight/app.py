import os
import re
import logging
import warnings
from typing import Optional

import torch
import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from transformers import AutoTokenizer, AutoModelForSequenceClassification

# === Warnings ===
warnings.filterwarnings("ignore")

# === Logging ===
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# === FastAPI App ===
app = FastAPI(
    title="Mental Health Prediction API",
    description="BERT-based mental health text classifier",
    version="1.0.0"
)

# === CORS Middleware ===
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# === Pydantic Models ===
class InputText(BaseModel):
    text: str

class PredictionResponse(BaseModel):
    prediction: str
    confidence: float
    scores: dict
    explanation: str
    crisis: bool

# === Constants ===
id2label = {0: "Anxiety", 1: "Depression", 2: "Normal", 3: "Suicidal"}

CRISIS_KEYWORDS = [
    "suicide", "kill myself", "end my life", "want to die",
    "no reason to live", "hurt myself", "wish I were dead", "give up on life"
]

NEGATION_PATTERNS = [
    r"(don't|do not|never|no|not|without)\s+.*anxiety",
    r"(not|never)\s+anxious",
    r"(don't|do not|never|no|not|without)\s+.*worry",
    r"(not|never)\s+worried"
]

# === Environment Configuration ===
HF_TOKEN = os.getenv("HUGGINGFACE_HUB_TOKEN")
MODEL_NAME = os.getenv("MODEL_NAME", "ourafla/mental-health-bert-finetuned")
PORT = int(os.getenv("PORT", 8080))
ENV = os.getenv("ENVIRONMENT", "production")

if not HF_TOKEN and ENV == "production":
    logger.warning("⚠️ HUGGINGFACE_HUB_TOKEN not set.")

# === Model Loading ===
@app.on_event("startup")
async def load_model():
    """Load model on startup."""
    global tokenizer, model
    try:
        logger.info(f"🔄 Loading model: {MODEL_NAME}...")
        tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME, token=HF_TOKEN)
        model = AutoModelForSequenceClassification.from_pretrained(
            MODEL_NAME,
            token=HF_TOKEN,
            num_labels=4,
            output_attentions=True
        )
        model.eval()
        logger.info("✅ Model loaded successfully.")
    except Exception as e:
        logger.error(f"❌ Failed to load model: {e}")
        raise RuntimeError(f"Model loading failed: {e}")

# === Helper Functions ===
def check_crisis(text: str) -> bool:
    """Check for crisis keywords."""
    return any(k in text.lower() for k in CRISIS_KEYWORDS)

def is_negated_anxiety(text: str) -> bool:
    """Check for negated anxiety patterns."""
    text_lower = text.lower()
    return any(re.search(p, text_lower) for p in NEGATION_PATTERNS)

def generate_explanation(tokens: list, attentions: torch.Tensor) -> str:
    """Generate explanation from attention weights."""
    try:
        avg_attn = torch.stack(attentions[-4:]).mean(dim=0)
        attn_scores = avg_attn.mean(dim=1).mean(dim=1)[0].detach().cpu().numpy()
        attn_scores = attn_scores / (attn_scores.max() + 1e-8)
        top_indices = np.argsort(attn_scores)[-6:][::-1].tolist()
        top_tokens = [
            tokens[i] for i in top_indices
            if tokens[i] not in ["[CLS]", "[SEP]", "[PAD]"]
        ]
        if top_tokens:
            return f"Key phrases: {', '.join(top_tokens[:3])}"
        return "No significant tokens identified."
    except Exception as e:
        return f"Explanation unavailable: {str(e)}"

# === API Routes ===
@app.get("/")
def health():
    """Health check endpoint."""
    return {
        "status": "running",
        "version": "1.0.0",
        "model": MODEL_NAME
    }

@app.get("/health/live")
def liveness():
    """Kubernetes liveness probe."""
    return {"status": "alive"}

@app.get("/health/ready")
def readiness():
    """Kubernetes readiness probe."""
    try:
        _ = model
        _ = tokenizer
        return {"status": "ready"}
    except Exception:
        raise HTTPException(status_code=503, detail="Service not ready")

@app.post("/predict", response_model=PredictionResponse)
def predict(input_data: InputText):
    """Predict mental health state from text."""
    
    text = input_data.text.strip()

    # === Input Validation ===
    if not 10 <= len(text) <= 2000:
        raise HTTPException(
            status_code=400,
            detail="Text must be between 10 and 2000 characters."
        )

    # === Crisis Detection ===
    if check_crisis(text):
        logger.warning(f"🚨 Crisis detected: {text[:50]}...")
        return PredictionResponse(
            prediction="CRISIS_ALERT",
            confidence=1.0,
            scores={},
            explanation="Crisis keywords detected.",
            crisis=True
        )

    # === Tokenize & Predict ===
    try:
        encoded = tokenizer(
            text, return_tensors="pt", truncation=True,
            padding=True, max_length=128
        )
        tokens = tokenizer.convert_ids_to_tokens(encoded["input_ids"][0])

        with torch.no_grad():
            outputs = model(**encoded)

        logits = outputs.logits
        attentions = outputs.attentions
        probs = torch.softmax(logits, dim=-1)[0]

    except Exception as e:
        logger.error(f"❌ Inference failed: {e}")
        raise HTTPException(
            status_code=500,
            detail="Model inference failed."
        )

    # === Post-Process ===
    pred_index = torch.argmax(probs).item()
    label = id2label[pred_index]
    scores = {id2label[i]: round(probs[i].item(), 4) for i in range(len(id2label))}

    # Edge-case corrections
    neutral_keywords = ["calm", "peaceful", "routine", "enjoy", "relax", "good", "normal", "pleasant", "happy"]
    if label == "Anxiety" and probs[pred_index] < 0.99:
        if any(w in text.lower() for w in neutral_keywords):
            label = "Normal"
    if label == "Anxiety" and is_negated_anxiety(text):
        label = "Normal"

    # === Generate Explanation ===
    explanation = generate_explanation(tokens, attentions)
    confidence = round(probs[list(id2label.values()).index(label)].item(), 4)

    logger.info(f"✅ Prediction: {label} (confidence: {confidence})")

    return PredictionResponse(
        prediction=label,
        confidence=confidence,
        scores=scores,
        explanation=explanation,
        crisis=False
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=PORT)
